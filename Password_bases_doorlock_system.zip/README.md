# Password_based_doorlock_system
embedded Password_bases_doorlock_system using 8051

# Brief

It was an 8051 Controller based project which was using Keypad as input interface and using 
EEPROM (Interfaced with I2C) as permanent storage to verify password from user and the 
stored password. Correct password will result in movement of motor (Connected using L293D) 
to open door. Failure will keep the door shut. 

# How to open files?

download full folder. use keil version 5 and password based door lock project file open
in application folder there is main file placed. driver code is in the driver folder.  